﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace service.Controllers
{
    public class DBConnection
    {
        private static MySqlConnection OpenConnection()
        {
            try
            {
                MySqlConnection connection = new MySqlConnection();
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
                connection.Open();
                return connection;
            }
            catch (Exception) { throw; }
        }

        public static async Task ExecuteNonQuery(MySqlCommand cmd)
        {
            MySqlConnection connection = null;
            using (connection = OpenConnection())
            {
                if (connection != null)
                {
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        public static async Task<DataSet> ExecuteReader(MySqlCommand cmd)
        {
            MySqlConnection connection = null;
            DataSet ds = new DataSet();
            {
                using (connection = OpenConnection())
                {
                    if (connection != null)
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                        await dataAdapter.FillAsync(ds);
                    }
                }
                return ds;
            }
        }
    }
}