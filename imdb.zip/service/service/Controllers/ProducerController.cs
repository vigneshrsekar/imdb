﻿using service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace service.Controllers
{
    [RoutePrefix(@"api")]
    public class ProducerController : ApiController
    {
        [Route(@"Producer")]
        [HttpPost]
        public async Task<HttpResponseMessage> AddProducer(ProducerModel data)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Producer.AddUpdateProducer(data));
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }
        [Route(@"Producer")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetProducers(ProducerModel data)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Producer.GetProducers());
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }
    }
}
