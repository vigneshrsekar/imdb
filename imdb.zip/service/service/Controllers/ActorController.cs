﻿using service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace service.Controllers
{
     [RoutePrefix(@"api")]
    public class ActorController : ApiController
    {
        [Route(@"Actor")]
        [HttpPost]
        public async Task<HttpResponseMessage> AddActor(ActorModel data)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Actor.AddUpdateActor(data));
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }

        [Route(@"Actor")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetActors(ActorModel data)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Actor.GetActors());
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }
    }
}
