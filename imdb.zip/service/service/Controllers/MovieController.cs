﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace service.Controllers
{
    [RoutePrefix(@"api")]
    public class MovieController : ApiController
    {
        [Route(@"Movie")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetMovies()
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Movie.GetMovies());
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }

        [Route(@"Movie")]
        [HttpPost]
        public async Task<HttpResponseMessage> AddMovies(MovieModel data)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Movie.AddMovie(data));
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }

        [Route(@"RemoveMovie")]
        [HttpPost]
        public async Task<HttpResponseMessage> RemoveMovie(MovieModel data)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, await Movie.DeleteMovie(data));
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }
    }
}
