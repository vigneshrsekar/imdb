﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace service.Controllers
{
    public class ResultSet
    {
        public bool IsError = false;
        public object Result = new StatusSucceeded();
    }

    public class StatusSucceeded
    {
        public string Status = "Succeeded";
    }
    public class Helper
    {
        public static bool IsNull(string data)
        {
            if (string.IsNullOrEmpty(data) || string.IsNullOrWhiteSpace(data))
            {
                return true;
            }
            return false;
        }
        public static bool IsDataTableEmpty(DataSet ds)
        {
            if (ds == null || ds.Tables == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count < 1)
            {
                return true;
            }
            return false;
        }

        public static bool IsDataSetNull(DataSet ds)
        {
            if (ds == null || ds.Tables == null || ds.Tables.Count < 1)
            {
                return true;
            }
            return false;
        }
        public static string ToString(dynamic data)
        {
            if (IsNull(data))
            {
                return "";
            }
            return data.ToString();
        }
        public static void UpdateTableName(DataSet dataSet)
        {

            int tableCount = dataSet.Tables.Count;
            if (tableCount % 2 != 0)
            {
                throw new Exception("Table count should be multiple of two");
            }

            for (int i = 0; i < tableCount; i += 2)
            {
                dataSet.Tables[i + 1].TableName = dataSet.Tables[i].Rows[0][0] as string;
            }

            int tableIndex = tableCount - 2;
            while (tableIndex >= 0)
            {
                DataTable table = dataSet.Tables[tableIndex];
                if (dataSet.Tables.CanRemove(table))
                {
                    dataSet.Tables.Remove(table);
                }

                tableIndex -= 2;
            }

        }

        public static List<Dictionary<string, object>> DataTableToDictionaryList(DataTable dt)
        {
            List<Dictionary<string, object>> dictionaries = new List<Dictionary<string, object>>();
            foreach (DataRow row in dt.Rows)
            {
                Dictionary<string, object> dictionary = Enumerable.Range(0, dt.Columns.Count)
                    .ToDictionary(i => dt.Columns[i].ColumnName, i => row.ItemArray[i]);
                dictionaries.Add(dictionary);
            }
            return dictionaries;
        }

        public static Dictionary<string, object> DataTableToDictionary(DataTable dt)
        {
            Dictionary<string, object> dictionary = new Dictionary<string, object>();
            foreach (DataRow row in dt.Rows)
            {
                dictionary = Enumerable.Range(0, dt.Columns.Count)
                     .ToDictionary(i => dt.Columns[i].ColumnName, i => row.ItemArray[i]);

            }
            return dictionary;
        }

        public static List<object> DataTableToListObject(DataTable dt)
        {
            List<object> rows = new List<object>();

            foreach (DataRow row in dt.Rows)
                rows.Add(row);

            return rows;
        }
       
        public static string ByteToBase64(dynamic data)
        {
            if (data != null && data.ToString() != "")
                return Encoding.UTF8.GetString((byte[])data);
            return "";
        }
    }

}