﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;

namespace service.Controllers
{
    public class Logger
    {

        public static void WriteError(string message)
        {
            try
            {
                //string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string path = System.Web.Hosting.HostingEnvironment.MapPath("~/logs");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                using (StreamWriter streamWriter = File.AppendText(path + "\\" + "log.txt"))
                {
                    streamWriter.WriteAsync("\r\n********Error Entry*******");
                    streamWriter.WriteAsync("\r\nDateTime: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
                    streamWriter.WriteAsync("\r\nError: " + message);
                    streamWriter.WriteAsync("\r\n-----------------------------------------------------");
                }
            }
            catch (Exception)
            {

            }
        }
        public static void WriteLog(string message)
        {
            try
            {
                //string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string path = System.Web.Hosting.HostingEnvironment.MapPath("~/logs");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                using (StreamWriter streamWriter = File.AppendText(path + "\\" + "log.txt"))
                {
                    streamWriter.WriteAsync("\r\n********Log Entry*******");
                    streamWriter.WriteAsync("\r\nDateTime: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
                    streamWriter.WriteAsync("\r\nMessage: " + message);
                    streamWriter.WriteAsync("\r\n-----------------------------------------------------");
                }
            }
            catch (Exception)
            {

            }
        }
        public static void WriteLine(string message)
        {
            string path = System.Web.Hosting.HostingEnvironment.MapPath("~/logs");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            using (StreamWriter streamWriter = File.AppendText(path + "\\" + "log.txt"))
            {
                streamWriter.WriteAsync("\r\nMessage: " + message);
            }
        }
    }
}