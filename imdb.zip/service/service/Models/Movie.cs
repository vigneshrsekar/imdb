﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace service.Controllers
{
    public class MovieModel
    {
        public int Id = 0;
        public string Name { get; set; }
        public string Year { get; set; }
        public string Poster { get; set; }
        public string Plot { get; set; }
        public int ProducerId { get; set; }
        public int[] ActorsId { get; set; }
    }
    public class Movie
    {
        static ResultSet resultSet;
        public static async Task<ResultSet> GetMovies()
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = "GetMovies";
            resultSet.IsError = false;
            DataSet movies = await DBConnection.ExecuteReader(cmd);
            List<Dictionary<string, object>> movieList = Helper.DataTableToDictionaryList(movies.Tables[0]);

            foreach (Dictionary<string, object> movie in movieList)
            {
                MySqlCommand actorCmd = new MySqlCommand();
                actorCmd.Parameters.AddWithValue("p_movieId", Convert.ToInt64(movie["id"]));
                actorCmd.CommandText = "GetMovieActors";
                DataSet actors = await DBConnection.ExecuteReader(actorCmd);
                //Helper.UpdateTableName(actors);
                movie.Add("actors", actors.Tables[0]);

                MySqlCommand producerCmd = new MySqlCommand();
                producerCmd.Parameters.AddWithValue("p_movieId", Convert.ToInt64(movie["id"]));
                producerCmd.CommandText = "GetMovieProducer";
                DataSet producer = await DBConnection.ExecuteReader(producerCmd);
                //Helper.UpdateTableName(producer);
                Dictionary<string, object> dic = Helper.DataTableToDictionary(producer.Tables[0]);
                movie.Add("producer", dic);
            }
            resultSet.Result = movieList;
            return resultSet;
        }

        public static async Task<ResultSet> AddMovie(MovieModel movieData)
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Parameters.AddWithValue("p_id", movieData.Id);
            cmd.Parameters.AddWithValue("p_poster", movieData.Poster);
            cmd.Parameters.AddWithValue("p_name", movieData.Name);
            cmd.Parameters.AddWithValue("p_plot", movieData.Plot);
            cmd.Parameters.AddWithValue("p_year", movieData.Year);
            cmd.Parameters.AddWithValue("p_movieId", 0).Direction = ParameterDirection.Output;
            cmd.CommandText = "AddUpdateMovie";

            await DBConnection.ExecuteReader(cmd);
            int movieId = Convert.ToInt32(cmd.Parameters["p_movieId"].Value);
            var addProducerTask = new Task(async () =>
            {
                MySqlCommand producerCmd = new MySqlCommand();
                producerCmd.Parameters.AddWithValue("p_movieId", movieId);
                producerCmd.Parameters.AddWithValue("p_producerId", movieData.ProducerId);
                producerCmd.CommandText = "MapProducer";
                await DBConnection.ExecuteReader(producerCmd);

            });

            var addActorsTask = new Task(async () =>
            {
                MySqlCommand unmap = new MySqlCommand();
                unmap.Parameters.AddWithValue("p_movieId", movieId);
                unmap.CommandText = "UnMapACtors";
                await DBConnection.ExecuteReader(unmap);

                foreach (int actorId in movieData.ActorsId)
                {
                    MySqlCommand actorCmd = new MySqlCommand();
                    actorCmd.Parameters.AddWithValue("p_movieId", movieId);
                    actorCmd.Parameters.AddWithValue("p_actorId", actorId);
                    actorCmd.CommandText = "MapActor";
                    await DBConnection.ExecuteReader(actorCmd);
                }
            });
            addProducerTask.Start();
            addActorsTask.Start();
            resultSet.IsError = false;
            return resultSet;
        }

        public static async Task<ResultSet> DeleteMovie(MovieModel data)
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Parameters.AddWithValue("p_id", data.Id);
            cmd.CommandText = "DeleteMovie";
            await DBConnection.ExecuteReader(cmd);
            resultSet.IsError = false;
            return resultSet;
        }
    }
}