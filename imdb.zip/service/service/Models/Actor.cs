﻿using MySql.Data.MySqlClient;
using service.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace service.Models
{
    public class ActorModel
    {
        public int ActorId = 0;
        public string Name;
        public string Gender;
        public string DOB;
        public string BIO;
    }
    public class Actor
    {
        static ResultSet resultSet;
        public static async Task<ResultSet> AddUpdateActor(ActorModel actorData)
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Parameters.AddWithValue("p_id", actorData.ActorId);
            cmd.Parameters.AddWithValue("p_name", actorData.Name);
            cmd.Parameters.AddWithValue("p_gender", actorData.Gender);
            cmd.Parameters.AddWithValue("p_dob", actorData.DOB);
            cmd.Parameters.AddWithValue("p_bio", actorData.BIO);
            cmd.CommandText = "AddUpdateActor";
            resultSet.IsError = false;
            await DBConnection.ExecuteReader(cmd);
            return resultSet;
        }
        public static async Task<ResultSet> GetActors()
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = "GetActors";
            resultSet.IsError = false;
            DataSet ds = await DBConnection.ExecuteReader(cmd);
            resultSet.Result = ds.Tables[0];
            return resultSet;
        }
    }
}