﻿using MySql.Data.MySqlClient;
using service.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace service.Models
{
    public class ProducerModel
    {
        public int ProducerId = 0;
        public string Name;
        public string Gender;
        public string DOB;
        public string BIO;
    }
    public class Producer
    {
        static ResultSet resultSet;
        public static async Task<ResultSet> AddUpdateProducer(ProducerModel data)
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Parameters.AddWithValue("p_id", data.ProducerId);
            cmd.Parameters.AddWithValue("p_name", data.Name);
            cmd.Parameters.AddWithValue("p_gender", data.Gender);
            cmd.Parameters.AddWithValue("p_dob", data.DOB);
            cmd.Parameters.AddWithValue("p_bio", data.BIO);
            cmd.CommandText = "AddUpdateProducer";
            resultSet.IsError = false;
            await DBConnection.ExecuteReader(cmd);
            return resultSet;
        }
        public static async Task<ResultSet> GetProducers()
        {
            resultSet = new ResultSet();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = "GetProducers";
            resultSet.IsError = false;
            DataSet ds=await DBConnection.ExecuteReader(cmd);
            resultSet.Result = ds.Tables[0];
            return resultSet;
        }
    }
}