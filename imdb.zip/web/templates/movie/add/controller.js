﻿app.controller('MovieCtrl', function ($scope, $ionicModal, $state, MovieService, $ionicPopup) {
    $scope.model = {};
    $scope.movieData = {};



    function onInit() {
        // Create the login modal that we will use later
        $ionicModal.fromTemplateUrl('templates/model/add-actor.html', {
            scope: $scope,
            animation: 'slide-in-up',
            //backdropClickToClose: false,
            //focusFirstInput: false,
        }).then(function (modal) {
            $scope.model = modal;
        });
        if (!isNull(MovieService.data)) {
            
            $scope.movieData = MovieService.data;
           
            $scope.pageTitle = "Update " + $scope.movieData.name;
        } else {
            $scope.movieData = {};
            $scope.pageTitle = "Add Movie";
        }
    }


    $scope.onClickAddProducer = function () {
        $scope.model.title = "Add Producer";
        $scope.model.data = {
            name: null,
            gender: "M",
            dob: new Date(),
            type:"P"
        };
        $scope.model.show();
    }

    $scope.onClickAddActor = function () {

        $scope.model.title = "Add Actor";
        $scope.model.data = {
            name: null,
            gender: "M",
            dob: new Date(),
            type:"A"
        };
        $scope.model.show();
    }
    
    $scope.onClickCreateEntity = function (data) {

        if (isNull(data.name)) {
            $scope.errorMessage = "Please Provide Name";
            return;
        }
        else if (isNull(data.gender)) {
            $scope.errorMessage = "Please Select Gender";
            return;
        }
        else if (isNull(data.dob)) {
            $scope.errorMessage = "Please Provide Date of birth";
            return;
        }
        else if (isNull(data.bio)) {
            $scope.errorMessage = "Please Provide Bio";
            return;
        }
        else {
            $scope.errorMessage = "";
        }
        var api = "";
        var requestPlayload = {};
        if (data.type == "P") {
            api = "Producer";
            requestPlayload.ProducerId = 0;
        } else {
            api = "Actor";
            requestPlayload.ActorId = 0;
        }
        requestPlayload.Name = data.name;
        requestPlayload.Gender = data.gender;
        var dob = "";
        if (!isNull(data.dob)) {
            dob = data.dob.getFullYear() + "-" + data.dob.getMonth() + "-" + data.dob.getDate();
        }
        requestPlayload.DOB = dob;
        requestPlayload.BIO = data.bio;
        apiService.Invoke(api, requestPlayload, Method.POST, function (result, isError) {
            if (!isError) {

                var alertPopup = $ionicPopup.alert({
                    title: 'Succeeded',
                    template: "Successfullly Added"
                });
                alertPopup.then(function (res) {
                    $scope.model.hide();
                });

                
                getActors();
                getProducers();
                $scope.$apply();
            }
        });
    }

    $scope.onClickBack = function () {

    }

    $scope.onClickAddMovie = function () {
        if(isNull($scope.movieData.name)){
            $scope.movieErrorMessage = "Please provide movie name";
            return;
        } else if (isNull($scope.movieData.year)) {
            $scope.movieErrorMessage = "Please provide year of release";
            return;

        } else if (isNull($scope.movieData.posterImage)) {
            $scope.movieErrorMessage = "Please upload movie poster";
            return;
        } else if (isNull($scope.movieData.producer) || isNull($scope.movieData.producer.id)) {
            $scope.movieErrorMessage = "Please select producer";
            return;
        } else if (isNull($scope.movieData.actors) || $scope.movieData.actors.length == 0) {
            $scope.movieErrorMessage = "Please select actor";
            return;

        } else {
            $scope.movieErrorMessage = "";
        }
        $scope.movieData;
        var requestPlayload = {};
        requestPlayload.Id = $scope.movieData.id == undefined ? 0 : $scope.movieData.id;
        requestPlayload.Name = $scope.movieData.name;
        requestPlayload.Year = $scope.movieData.year;
        requestPlayload.Poster = $scope.movieData.posterImage;
        requestPlayload.Plot = $scope.movieData.plot;
        requestPlayload.ProducerId = $scope.movieData.producer.id;
        var actors = [];
        for (let i = 0; i < $scope.movieData.actors.length; i++) {
            actors.push($scope.movieData.actors[i].id);
        }
        requestPlayload.ActorsId = actors;

        apiService.Invoke(API.Movie, requestPlayload, Method.POST, function (result, isError) {
            if (!isError) {
                var template="";
                if($scope.movieData.id==0)
                {
                    template = $scope.movieData.name+' is added to movie list.';
                }else{
                    template = $scope.movieData.name+' is updated.';
                }
                var alertPopup = $ionicPopup.alert({
                    title: 'Succeeded',
                    template:template
                    });
                alertPopup.then(function (res) {
                    $state.go('app.movies');
                });
            }
        });
    }

   

    $scope.modelClose = function () {
        $scope.model.hide();
    }

    $scope.ifSelectedActor = function (actorId) {
        if (!isNull($scope.movieData.actors)) {
            var actors = $scope.movieData.actors;
            for (let i = 0; i < actors.length; i++) {
                if (actors[i].id == actorId)
                    return true
            }
        }
        return false;
    }

    $scope.genderList = [{ name: "Male", id: 1 }, { name: "Female", id: 2 }]

    document.getElementById("poster").addEventListener("change", onSelectPoster);
    function onSelectPoster() {
        var ele = document.getElementById("poster");
        getBase64(ele.files[0]);
    }


    function getBase64(file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            //document.getElementById("show-poster").src = e.target.result;
            $scope.movieData.posterImage = e.target.result;
            $scope.$apply();
        };
        reader.readAsDataURL(file);
    }

    function getProducers() {
        apiService.Invoke(API.Producer, null, Method.GET, function (result, isError) {
            if (!isError) {
                $scope.producers = result.Result;
                $scope.$apply();
            }
        });
    }

    function getActors() {
        apiService.Invoke(API.Actor, null, Method.GET, function (result, isError) {
            if (!isError) {
                $scope.actors = result.Result;
                $scope.$apply();
            }
        });
    }
    getActors();
    getProducers();

    $scope.searchTerm;
    $scope.clearSearchTerm = function () {
        $scope.searchTerm = '';
    };
    onInit();
})