﻿app.controller('MoviesCtrl', function ($scope, $ionicModal, $ionicPopup, $state, MovieService) {
    $scope.AddMovieModel = {};

    $scope.onClickAddMovie = function (data) {

        MovieService.update(data);
        $state.go('app.single');
    }
    prepareModel();
    function prepareModel() {
        // Create the login modal that we will use later
        $ionicModal.fromTemplateUrl('templates/model/view-actor.html', {
            scope: $scope,
            animation: 'slide-in-up',
            //backdropClickToClose: false,
            //focusFirstInput: false,
        }).then(function (modal) {
            $scope.model = modal;
        });
    }

    function showAlert() {
        var alertPopup = $ionicPopup.alert({
            title: 'Dont eat that!',
            template: 'It might taste good'
        });
        alertPopup.then(function (res) {
            console.log('Thank you for not eating my delicious ice cream cone');
        });
    }

    $scope.onClickActor = function (data) {
        $scope.model.title = "Update Actor";
        $scope.model.data = {
            id:data.id,
            name: data.name,
            gender: data.gender,
            dob: new Date(data.dob),
            type: "A",
            bio: data.bio
        };
        $scope.model.show();
    }

    $scope.onClickProducer = function (data) {
        $scope.model.title = "Update Producer";
        $scope.model.data = {
            name: data.name,
            gender: data.gender,
            dob: new Date(data.dob),
            type: "P",
            id: data.id,
            bio:data.bio
        };
        $scope.model.show();
    }

    $scope.modelClose = function () {
        $scope.model.hide();
    }

    $scope.onClickUpdateEntity = function (data) {

        if (isNull(data.name)) {
            $scope.errorMessage = "Please Provide Name";
            return;
        }
        else if (isNull(data.gender)) {
            $scope.errorMessage = "Please Select Gender";
            return;
        }
        else if (isNull(data.dob)) {
            $scope.errorMessage = "Please Provide Date of birth";
            return;
        }
        else if (isNull(data.bio)) {
            $scope.errorMessage = "Please Provide Bio";
            return;
        }
        else {
            $scope.errorMessage = "";
        }
        var api = "";
        var requestPlayload = {};
        if (data.type == "P") {
            api = "Producer";
            requestPlayload.ProducerId = data.id;
        } else {
            api = "Actor";
            requestPlayload.ActorId = data.id;
        }
        requestPlayload.Name = data.name;
        requestPlayload.Gender = data.gender;
        var dob = "";
        if (!isNull(data.dob)) {
            dob = data.dob.getFullYear() + "-" + data.dob.getMonth() + "-" + data.dob.getDate();
        }
        requestPlayload.DOB = dob;
        requestPlayload.BIO = data.bio;
        apiService.Invoke(api, requestPlayload, Method.POST, function (result, isError) {
            if (!isError) {

                var alertPopup = $ionicPopup.alert({
                    title: 'Succeeded',
                    template: "Successfullly Added"
                });
                alertPopup.then(function (res) {
                    $scope.model.hide();
                });
                getMovies();
                $scope.$apply();
            }
        });
    }


    function getMovies(callback) {
        apiService.Invoke(API.Movie, null, Method.GET, function (result, isError) {
            if (!isError) {
                if (!isNull(callback)) {
                    callback();
                }
                $scope.movieList = result.Result;
                $scope.$apply();
            }
        });
    }
    $scope.onClickSync = function () {
        getMovies(function () {
            var alertPopup = $ionicPopup.alert({
                title: 'Succeeded',
                template: "Movies has been successfully updated,"
            });
            alertPopup.then(function (res) {
            });
        });
    }

    $scope.onClickDeleteMovie = function (id) {
        var requestPayload = {};
        requestPayload.ID = id;
        apiService.Invoke(API.DeleteMovie, requestPayload, Method.POST, function (result, isError) {
            if (!isError) {
                getMovies();
                var alertPopup = $ionicPopup.alert({
                    title: 'Succeeded',
                    template: "Movies has been successfully removed."
                });
                alertPopup.then(function (res) {

                });
            }
        });
    }

    $scope.init = function () {
        getMovies();
    };




})