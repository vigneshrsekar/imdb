﻿app.controller('ModelCtrl', function ($scope, $ionicModal) {
    alert("test")
});