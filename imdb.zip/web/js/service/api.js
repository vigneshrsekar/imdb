﻿var Method = {
    GET: "GET",
    POST: "POST",
    PUT: "PUT",
    DELETE: "DELETE"
}

var API = {
    Movie: "Movie",
    Producer: "Producer",
    Actor: "Actor",
    DeleteMovie: "RemoveMovie"
};

function APIService() { }

APIService.prototype = new ServiceBase();

APIService.prototype.Invoke = function (api, data, method, callBack, loader, isAuthenticationRequired) {
    return this.InvokeAPI(apiUrl + api, data, method, callBack, loader, isAuthenticationRequired);
}

var apiService = new APIService;