﻿function ServiceBase() { }

ServiceBase.prototype.InvokeAPI = function (api, data, method, callBack, loader) {

    try {
        //blockUI();
        var request = $.ajax({
            async: true,
            crossDomain: true,
            url: api,
            type: method,
            data: JSON.stringify(data),
            dataType: "json",
            contentType: "charset=utf-8",
            headers: {
                "Content-Type": "application/json"
                //  "Cache-Control": "no-cache"
            },
        });

        request.done(function (response) {
            if (loader != false)
                //unblockUI();
                callBack(response, false);
        });

        request.fail(function (response, testStatus) {
            if (loader != false)
                //unblockUI();
                callBack(response, true);
        });

    }
    catch (ex) {
        console.log(ex)
        //log("Service Exception: " + ex);
    }
}
function blockUI() {
    if (!($('body').hasClass('svg-loader'))) {
        $('body').addClass('svg-loader');
        $('body').prepend("<div class='blockUI'><div><img src='images/loader.svg'></div></div>");
        $('body').css('overflow', 'hidden');
    }
}

function unblockUI() {
    $('body').removeClass('svg-loader');
    $('body').find('.blockUI').fadeOut("slow", function () { $(this).remove(); });
    $('body').css('overflow-y', 'auto');
}