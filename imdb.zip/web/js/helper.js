﻿
function isNull(data) {
    if (data == undefined || data == null || data == "") {
        return true;
    }
    else if (data == typeof 'object') {
        if (Object.keys(data).length == 0)
            return true;
    }
    return false;
}