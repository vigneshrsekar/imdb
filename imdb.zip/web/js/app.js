
// Angular Application
var app = angular.module('imdb', ['ionic', 'ngMaterial']);
var apiUrl = "http://localhost/imdb/service/api/";

app.run(function ($ionicPlatform) {
  $ionicPlatform.ready(function () {
    if (window.cordova && window.Keyboard) {
      window.Keyboard.hideKeyboardAccessoryBar(true);
    }

    if (window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})

app.config(function ($stateProvider, $urlRouterProvider) {
  $stateProvider
    .state('app', {
      url: '/app',
      abstract: true,
      templateUrl: 'templates/menu/menu.html',
      controller: 'AppCtrl'
    })

    .state('app.actors', {
      url: '/actors',
      views: {
        'menuContent': {
          templateUrl: 'templates/actor/actors.html'
        }
      }
    })

    .state('app.producers', {
      url: '/producers',
      views: {
        'menuContent': {
          templateUrl: 'templates/producer/producers.html'
        }
      }
    })
    .state('app.movies', {
      url: '/movies',
      views: {
        'menuContent': {
          templateUrl: 'templates/movie/movies.html',
          controller: 'MoviesCtrl'
        }
      }
    })

    .state('app.single', {
      url: '/addmovie',
      views: {
        'menuContent': {
          templateUrl: 'templates/movie/add/add-movie.html',
          controller: 'MovieCtrl'
        }
      }
    });
  $urlRouterProvider.otherwise('/app/movies');
});

app.factory('MovieService', function () {
    var data = {};
    return {
        data: data,
        update: function (data) {
            this.data=data;
        }
    };
});